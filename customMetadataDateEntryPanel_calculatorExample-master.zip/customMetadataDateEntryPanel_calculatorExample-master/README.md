# customMetadataDateEntryPanel_calculatorExample
This is an example custom metadata data entry panel for TruEdit based on the great, simple scientific calculator example authored by Gregory Getchell at https://codepen.io/ggetchell/pen/KVgrYq.
